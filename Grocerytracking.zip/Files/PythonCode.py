import re
import string


def printsomething():
    print("Hello from python!")

def PrintMe(v):
    print("You sent me: " + v)
    return 0;

def SquareValue(v):
    return v * v

#fuction to return MultiplicationTable
def MultiplicationTable(num):  
    strLine = ''
    for x in range(1,11):
      print(strLine + str(num)+' x '+str(x)+' = '+str(x * num))
    return 0;
#function to return the double of a value
def DoubleValue(v):
    return v * 2


